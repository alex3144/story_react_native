OTF and TTF: TypoGraphica (Regular, Italic, Bold, Italic, Bold Italic, and Outlines)
version: 3.0 Updated on 3/7/2016
Dennis Ludlow 2015 all rights reserved
by Sharkshock 
dennis@sharkshock.net


Hey everybody meet TypoGraphica. My longtime project Mouser has undergone various updates over the years and finally morphed into something of a hybrid. As with much older works a decision has to be made whether or not it's worth it to invest the time to give it a facelift or simply 
abandon it. This Geometric Sans is noted for it's embolded letter weight and characteristic slants. It's appearance is commanding on a front page or cover but won't dominate with it's simplistic design. OTF features like stylistic sets, ligatures, alternates, ordinals, and fractions are included. This 
typeface contains basic and supplemental latin, numbers, punctuation, European accents, Cyrillic characters, and kerning. All 5 versions are included with commercial license or $25 donation via PayPal. Ultra smooth and aesthetically pleasing 
TypoGraphica will make an attractive pick for your next display font. 

This font like my others are free for personal use only as long as this readme file stays intact. For commercial use please contact me at dennis@sharkshock.net to discuss an end user license agreement. You can also visit www.sharkshock.net/license for more info. I also design custom fonts for 
businesses, logos, and many other things. If you'd like to leave me a PayPal donation you can use my email address above. Your generosity will be most appreciated! 


visit www.sharkshock.net for more and take a bite out of BORING design!

